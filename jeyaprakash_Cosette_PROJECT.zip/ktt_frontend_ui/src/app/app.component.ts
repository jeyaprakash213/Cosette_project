


import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
// export class AppComponent {
//   title = 'my-app';
// }
export class AppComponent implements OnInit {
  EmployeeDatas: any[] = [];
  EmployeeName: any;
  EmployeeEmail: any;
  EmployeePhone: any;
  selectedStatus: any;
  StockDatas: any[] = [];
  HistoryDatas: any[] = [];


  AssetserialNumber: any;
  Assetmake: any;
  Assetcategory: any;
  AssetValue: any;
  Assetmodel: any;
  Assetholder: any;
  getInStockDatas: any[] = [];



  constructor(private http: HttpClient) {
    this.getEmployee();
    this.getStock();
    this.getHistory()
    this.getInStock()
  }
  ngOnInit(): void {

    // this.getEmployee()
  }



  addEmployee() {
    console.log(JSON.stringify(this.selectedStatus))
    let bodyData = {
      "EmployeeName": this.EmployeeName,
      "EmployeeEmail": this.EmployeeEmail,
      "EmployeePhone": this.EmployeePhone,
      "selectedStatus": "active"
    };

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:3000/Employeeregister", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);

      // this.ProductArray.push(resultData.Products)
      // console.log("ProductArray", this.ProductArray);
      alert("Product add Successfully")
      this.getEmployee();
      this.EmployeeName = '';
      this.EmployeeEmail = '';
      this.EmployeePhone = '';
      this.selectedStatus = '';

      // this.getAllpurchaseProducts()

    });







  }

  addAsset() {
    let bodyData = {
      "serialNumber": this.AssetserialNumber,
      "make": this.Assetmake,
      "category": this.Assetcategory,
      "value": this.AssetValue,
      "model": this.Assetmodel,
      "holder": this.Assetholder,
      "status": "in_stock"
    };

    if (this.Assetholder) {
      bodyData.status = "sold"
    }

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:3000/Assetregister", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);

      // this.ProductArray.push(resultData.Products)
      // console.log("ProductArray", this.ProductArray);
      alert("Product add Successfully")
      this.getInStock()

      this.AssetserialNumber = '';
      this.Assetmake = '';
      this.Assetcategory = '';
      this.AssetValue = '';
      this.Assetmodel = '';
      this.Assetholder = '';


    })
  }

  getInStock() {
    console.log("jjjjjjjjjjj")
    this.http.get("http://localhost:3000/AssetInstock")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData.data.Products);
        this.getInStockDatas = [resultData.data.Products];
        console.log("this.getInStockDatas", this.getInStockDatas);
        // this.selectedProduct = resultData.Products.productName
      });
  }


  getEmployee() {
    console.log("jjjjjjjjjjj")
    this.http.get("http://localhost:3000/searchEmployee")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData.data.Products);
        this.EmployeeDatas = resultData.data.Products;
        console.log("this.EmployeeDatas", this.EmployeeDatas);
        // this.selectedProduct = resultData.Products.productName
      });
  }

  getStock() {
    console.log("jjjjjjjjjjj")
    this.http.get("http://localhost:3000/getAllAsset")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData.data.Products);
        this.StockDatas = resultData.data.Products;
        console.log("this.StockDatas", this.StockDatas);
        // this.selectedProduct = resultData.Products.productName
      });
  }

  getHistory() {
    console.log("jjjjjjjjjjj")
    this.http.get("http://localhost:3000/getAllHistoryAsset")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData.data.Products);
        this.HistoryDatas = resultData.data.Products;
        console.log("this.HistoryDatas", this.HistoryDatas);
        // this.selectedProduct = resultData.Products.productName
      });
  }

  getTotalValue(): number {
    return this.StockDatas?.reduce((acc, item) => acc + (Number(item.value) || 0), 0);
  }

  getTotalValueHistory(): number {
    return this.HistoryDatas?.reduce((acc, item) => acc + (Number(item.value) || 0), 0);
  }


  saveEmployee() {

  }



  // editIndex: number | null = null;
  // originalData: any = null;

  // startEdit(index: number) {
  //   this.editIndex = index;
  //   // clone the original row in case user cancels
  //   this.originalData = { ...this.getInStockDatas[index] };
  // }

  // saveEdit() {
  //   this.editIndex = null;
  //   this.originalData = null;
  //   // You can also call an API to save the edited data here
  // }

  // cancelEdit() {
  //   if (this.editIndex !== null) {
  //     this.getInStockDatas[this.editIndex] = this.originalData;
  //   }
  //   this.editIndex = null;
  //   this.originalData = null;
  // }





}