const { Employee, Asset, Transaction } = require('./model');
// const { v4: uuidv4 } = require("uuid");
const { uuid } = require('uuidv4');

module.exports = {

    create: function (req, res, next) {
        let AssetQuery = {};
        AssetQuery.serialNumber = req.body.serialNumber;
        Asset.findOne(AssetQuery, function (err, AssetInfo) {
            if (AssetInfo) {
                console.log("Info", AssetInfo)
                res.status(200).send({
                    message: "This Asset  allready registered!!!",
                });
            } else {
                let Assets = {};
                Assets.assetId = uuid();
                Assets.serialNumber = req.body.serialNumber;
                Assets.make = req.body.make;
                Assets.model = req.body.model;
                Assets.value = req.body.value;
                Assets.branch = req.body.branch;
                Assets.category = req.body.category;
                Assets.holder = req.body.holder;
                Assets.status = "in_stock"
                if (req.body.holder) {
                    Assets.status = "sold"
                }

                Asset.create(Assets, function (err, result) {
                    if (err) next(err);
                    else {
                        res.status(200).send({
                            message: "Asset registered successfully!!!",
                            data: { userInfo: result },
                        });
                    }

                });

            }
        });
    },
    updateById: function (req, res) {
        let AssetQuery = {};
        AssetQuery._id = req.body._id;
        if (req.body.holder) {
            req.body.status = "active"
        }
        Asset.findByIdAndUpdate(AssetQuery, req.body, function (err, AssetInfo) {
            if (!AssetInfo) {
                res.status(200).send({
                    message: "No Asset detail found!!!",
                });
            } else {

                res.status(200).send({
                    message: "updated Asset detail !!!",
                    // data: { userInfo: userInfo },
                });
            }
        });
    },
    getById: function (req, res) {
        let AssetQuery = {};
        AssetQuery.status = "in_stock";
        Asset.findOne(AssetQuery, function (err, Products) {
            if (!Products) {
                res.status(200).send({
                    message: "No Asset detail found!!!",
                });
            } else {
                console.log("userInfo", Products)
                res.status(200).send({
                    message: "Asset detail found!!!",
                    data: { Products: Products },
                });
            }
        });
    },
    getAll: function (req, res, next) {
        console.log("jjjjjjjjj", req.body)
        let productQuery = {};
        if (req.body) {
            productQuery = req.body
        }
        // productQuery.createBy = req.body.createBy;
        Asset.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj",)
            if (err) {
                next(err);
            } else {
                console.log("jjjjjjjjj", Products)
                res.status(200).send({
                    message: "Products list found!!!",
                    data: { Products: Products },
                });
            }
        });
    },
    getHistoryAll: function (req, res, next) {
        console.log("jjjjjjjjj", req.body)
        let productQuery = { status: "sold" };

        // productQuery.createBy = req.body.createBy;
        Asset.find(productQuery, function (err, Products) {
            console.log("jjjjjjjjj",)
            if (err) {
                next(err);
            } else {
                console.log("jjjjjjjjj", Products)
                res.status(200).send({
                    message: "Products list found!!!",
                    data: { Products: Products },
                });
            }
        });
    },
    Transaction: function (req, res, next) {
        let AssetQuery = {};
        AssetQuery.serialNumber = req.body.serialNumber;
        Transaction.findOne(AssetQuery, function (err, AssetInfo) {
            if (!AssetInfo) {
                console.log("Info", AssetInfo)
                res.status(200).send({
                    message: "This Asset  not found!!!",
                });
            } else {
                let Assets = {};

                Assets.serialNumber = req.body.serialNumber;
                Assets.employee = req.body.employee;
                Assets.action = req.body.action;
                Assets.reason = req.body.reason;

                Transaction.create(Assets, function (err, result) {
                    if (err) next(err);
                    else {
                        res.status(200).send({
                            message: "Asset Transaction successfully!!!",
                            data: { userInfo: result },
                        });
                    }

                });

            }
        });
    },
    AssetReport: function (req, res) {
        let AssetQuery = {};
        AssetQuery._id = req.body._id;

        Transaction.findByIdAndUpdate(AssetQuery, req.body, function (err, AssetInfo) {
            if (!AssetInfo) {
                res.status(200).send({
                    message: "No Asset detail found!!!",
                });
            } else {

                res.status(200).send({
                    message: "updated Asset detail !!!",
                    // data: { userInfo: userInfo },
                });
            }
        });
    }
};