const express = require('express');
const app = express();
const connectDB = require('./db');
const EmployeeController = require('./Employee');
const AssetController = require('./Asset');
const bodyParser = require('body-parser');
const PORT = 3000;
const cors = require('cors');
// Connect to MongoDB
connectDB();

// Express middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'))


app.use(cors());



app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());




// Employee Master:
app.post('/Employeeregister', EmployeeController.create);
app.put('/EmployeeupdateById', EmployeeController.updateById);
app.get('/EmployeeData', EmployeeController.getById);

// search Employee
app.get('/searchEmployee', EmployeeController.getAll);


// Asset Master:
app.post('/Assetregister', AssetController.create);
app.put('/AssetupdateById', AssetController.updateById);
app.get('/AssetInstock', AssetController.getById);

// Stock View: 
app.get('/getAllAsset', AssetController.getAll);

// Asset History:
app.get('/getAllHistoryAsset', AssetController.getHistoryAll);

// Transaction
app.post('/AssetTransaction', AssetController.Transaction);

// Issue & Return Scrap Asset:
app.post('/AssetReport', AssetController.AssetReport);

// Server start
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});