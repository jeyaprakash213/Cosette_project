const { Employee, Asset } = require('./model');



module.exports = {

    create: function (req, res, next) {
        console.log("new", req)
        let userQuery = {};
        userQuery.EmployeeName = req.body.EmployeeName;
        Employee.findOne(userQuery, function (err, userInfo) {
            if (userInfo) {
                console.log("userInfo", userInfo)
                res.status(200).send({
                    message: "Employee  allready registered!!!",
                });
            } else {
                let user = {};
                user.EmployeeName = req.body.EmployeeName;
                user.EmployeeEmail = req.body.EmployeeEmail;
                user.EmployeePhone = req.body.EmployeePhone;
                user.selectedStatus = req.body.selectedStatus;
                Employee.create(user, function (err, result) {
                    if (err) next(err);
                    else {
                        res.status(200).send({
                            message: "Employee registered successfully!!!",
                            data: { userInfo: result },
                        });
                    }
                    res.status(200).send({ message: "User added successfully!!!" });
                });




            }
        });
    },
    updateById: function (req, res) {
        let userQuery = {};
        userQuery._id = req.body._id;
        Employee.findByIdAndUpdate(userQuery, req.body, function (err, userInfo) {
            if (!userInfo) {
                res.status(200).send({
                    message: "No Employee detail found!!!",
                });
            } else {
                res.status(200).send({
                    message: "updated Employee detail !!!",
                    // data: { userInfo: userInfo },
                });
            }
        });
    },
    getById: function (req, res) {
        let userQuery = {};
        userQuery._id = req.body._id;
        Employee.findOne(userQuery, function (err, userInfo) {
            if (!userInfo) {
                res.status(200).send({
                    message: "No Employee detail found!!!",
                });
            } else {
                console.log("userInfo", userInfo)
                res.status(200).send({
                    message: "Employee detail found!!!",
                    data: { userInfo: userInfo },
                });
            }
        });
    },
    getAll: function (req, res, next) {
        console.log("jjjjjjjjj", req.body)
        let productQuery = {};
        if (req.body) {
            productQuery = req.body
        }
        // productQuery.createBy = req.body.createBy;
        Employee.find(productQuery, function (err, Products) {

            if (err) {
                next(err);
            } else {
                console.log("jjjjjjjjjsssssssss")
                res.status(200).send({
                    message: "Employee list found!!!",
                    data: { Products: Products },
                });
            }
        });
    }

};